<?php

return [
    'navigation' => [
        'index',
        'add',
        'edit',
        'manage',
        'remove'
    ]
];