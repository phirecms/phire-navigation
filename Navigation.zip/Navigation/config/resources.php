<?php

return [
    'navigation' => [
        'index',
        'add',
        'edit',
        'remove'
    ]
];