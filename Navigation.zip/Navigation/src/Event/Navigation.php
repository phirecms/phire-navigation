<?php

namespace Navigation\Event;

use Navigation\Model;
use Navigation\Table;
use Pop\Application;
use Phire\Controller\AbstractController;

class Navigation
{

    /**
     * Bootstrap the module
     *
     * @param  Application $application
     * @return void
     */
    public static function bootstrap(Application $application)
    {

    }

}
